#include "m1.h"


void m1_f1()
{
    printf("TEST M1");
}
