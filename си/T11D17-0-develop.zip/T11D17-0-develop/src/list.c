#include "list.h"
#define DOORS_COUNT 15
#define MAX_ID_SEED 1000
struct node* init(struct door* door) {
    struct node* temp = malloc(sizeof(struct node*));
    temp->elem = door;
    temp->next = NULL;
    return temp;
}
struct node* add_door(struct node* elem, struct door* door) {
    struct node* temp = malloc(sizeof(struct node*));
    temp->elem = door;
    temp->next = NULL;
    struct node* head = elem;
    while (head->next != NULL) {
        head = head->next;
    }
    head->next = temp;
    return elem;
}
struct node* find_door(int door_id, struct node* root) {
    struct node* temp = root;
    int found = 0;
    while (temp->next != NULL) {
        if (temp->elem->id == door_id) {
            found = 1;
            break;
        }
        temp = temp->next;
    }
    if (found == 1) {
        return temp;
    } else {
        return NULL;
    }
}
struct node* remove_door(struct node* elem, struct node* root) {
    if (root == elem) {
        struct node* temp = root;
        free(root);
        return temp->next;
    } else {
        struct node* head = root;
        while (head->next != NULL) {
            if (head->next == elem) {
                head->next = head->next->next;
                free(elem);
                return root;
            }
            head = head->next;
        }
        return elem;
    }
}
void destroy(struct node* root) {
    struct node* prev = NULL;
    while (root->next) {
        prev = root;
        root = root->next;
        free(prev);
    }
    free(root);
}
