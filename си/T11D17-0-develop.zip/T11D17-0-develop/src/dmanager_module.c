#include "door_struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
#define DOORS_COUNT 15
#define MAX_ID_SEED 1000
void initialize_doors(struct door* doors);
void sort(struct door* doors);
void close_doors(struct door* doors);
void output(struct door* doors);
int main() {
    #ifdef DOR_MANAGER
    struct door doors[DOORS_COUNT];
    initialize_doors(doors);
    sort(doors);
    close_doors(doors);
    output(doors);
    #endif
    #ifdef LIST_TEST
        list_test();
    #endif
    return 0;
}

// Doors initialization function
// ATTENTION!!!
// DO NOT CHANGE!
void initialize_doors(struct door* doors) {
    srand(time(0));
    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < DOORS_COUNT; i++) {
        doors[i].id = (i + seed) % DOORS_COUNT;
        doors[i].status = rand() % 2;
    }
}


void sort(struct door* doors) {
    for (int i = 0; i < DOORS_COUNT -1; i++) {
        for (int count = 0; count < DOORS_COUNT - i -1; count++) {
            if (doors[count].id > doors[count+1].id) {
                int temp = doors[count].id;
                doors[count].id = doors[count+1].id;
                doors[count+1].id = temp;
            }
        }
    }
}


void close_doors(struct door* doors) {
    for (int i = 0; i < DOORS_COUNT; i++) {
        if (doors[i].status == 1) {
            doors[i].status = 0;
            }
    }
}

void output(struct door* doors) {
    for (int i = 0; i < DOORS_COUNT; i++)
        printf("%d, %d\n", doors[i].id, doors[i].status);
}
