#ifndef SRC_DOOR_STRUCT_H_
#define SRC_DOOR_STRUCT_H_

struct door {
    int id;
    int status;
};
void list_test();
void initialize_doors(struct door* doors);
void bubble_sort(struct door* doors);
void close_doors(struct door* doors);
void output(struct door* doors);

#endif  //  SRC_DOOR_STRUCT_H_
