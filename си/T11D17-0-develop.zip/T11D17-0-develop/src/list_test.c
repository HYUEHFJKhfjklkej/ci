#include "list.h"
#include <stdio.h>
#define DOORS_COUNT 15
#define MAX_ID_SEED 1000
void list_test() {
struct door doors[DOORS_COUNT];
    initialize_doors(doors);
    output(doors);
    struct node* List = init(&doors[0]);
    for (int i = 1; i < DOORS_COUNT; i++) {
        List = add_door(List, &doors[i]);
    }
    if (List->next->elem->id == (&doors[1])->id) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL");
    }
    struct node* Test = find_door(6, List);
    List = remove_door(Test, List);
    if (find_door(6, List) == NULL) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL");
    }
    if (find_door(7, List) != NULL) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL");
    }
    destroy(List);
}
