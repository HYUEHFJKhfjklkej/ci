#include <stdio.h>
#include <stdlib.h>

int input(int *a, int n);
void sort(int *a, int n);
void output(int *a, int n);
int main() {
    int n;
    char str;
    if ((scanf("%d%c", &n, &str) == 2) && (str == '\n') && (n > 0)) {
        int *a = (int *)malloc(n * sizeof(int));
        if (input(a, n) != 1) {
                    sort(a, n);
                    output(a, n);
        } else {
            printf("n/a");
        }
        free(a);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int n) {
    int flag = 0;
    char str;
        for (int  i = 0; i < n; i++) {
            if ((scanf("%d%c", &a[i], &str) != 2) || ((str != ' ') && (str != '\n'))) {
                flag = 1;
            }
        }
        flag = ((str == '\n') && (!flag) ? 0 : 1);
    return flag;
}
void sort(int *a, int n) {
    for (int i = 0; i < n-1; i++) {
        for (int count = 0; count < n-1; count++) {
            if (a[count] > a[count+1]) {
                int temp = a[count];
                a[count] = a[count+1];
                a[count+1] = temp;
            }
        }
    }
}
void output(int *a, int n) {
for (int i = 0 ; i < n; i ++) {
       if ((n-1) == i) {
        printf("%d", a[i]);
        } else {
           printf("%d ", a[i]);
       }
}
}
