read -p "Введите имя файла для компиляции " file_in
if [ -f $file_in ]
then
echo "ПРОВЕРКА ОФОРМЛЕНИЯ==========================="
python3 /Users/greengrb/Desktop/T03D03-0/materials/linters/cpplint.py --extensions=c $file_in
echo "ПРОВЕРКА ОФОРМЛЕНИЯ==========================="
read -p "Введите желаемое имя исполняемого файла  " file_out
echo "ФАЙЛ $file_out УСПЕШНО СОЗДАН ДЛЯ ЗАПУСКА ИСПОЛЬЗУЙ ./$file_out==========================="
gcc -std=c11 -Wall -Werror -Wextra -o $file_out $file_in
else
echo "$file_in файл НЕ найден работа завершена"
fi

