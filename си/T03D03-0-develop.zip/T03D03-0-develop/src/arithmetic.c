#include <stdio.h>

int main() {
    int ac, bc;
    float a, b;
    int summa(int a, int b);
    int raznosti(int a, int b);
    int twik(int a, int b);
    int quatro(int a, int b);
    int vivod(int p);

    if ((scanf("%f", &a) !=1) || (scanf("%f", &b) !=1)) {
        printf("n/a");
        return 1;
    }
    if ((vivod(b) == 0)) {
//        ac = (int)a;
//        bc = (int)b;
        printf("%d %d %d %s", summa(a, b), raznosti(a, b), twik(a, b), "n/a");
        return (1);
    }
    if ((vivod(a) == a) && ((vivod(b) == b))) {
//        ac = (int)a;
//        bc = (int)b;
        printf("%d %d %d %d", summa(a, b), raznosti(a, b),
               twik(a, b), quatro(a, b));
    } else {
        printf("n/a");
    }
    return 0;
}
int summa(int a, int b) {
    return a + b;
}

int raznosti(int a, int b) {
    return a - b;
}

int twik(int a, int b) {
    return a * b;
}

int quatro(int a, int b) {
    return a / b;
}

int vivod(int p) {
    return p;
}
