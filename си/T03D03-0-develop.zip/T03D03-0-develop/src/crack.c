#include <stdio.h>

int main() {
float x, y;
if ((scanf("%f", &x) == 1) && (scanf("%f", &y) == 1)) {
    if (((x*x)+(y*y)) < 25) {
        printf("GOTCHA");
    } else {
        printf("MISS");
    }
} else {
    printf("n/a");
}
}
