#include <stdio.h>
float a, b;
int vivod(int p);
int main() {
if ((scanf("%f", &a) != 1) || (scanf("%f", &b) != 1)) {
    printf("n/a");
    return 1;
}
    if ((vivod(a) == a) && ((vivod(b) == b))) {
        if (a > b) {
            printf("%d", vivod(a));
        } else {
            printf("%d", vivod(b));
        }
    } else {
        printf("n/a");
    }
}
int vivod(int p) {
    return p;
}
