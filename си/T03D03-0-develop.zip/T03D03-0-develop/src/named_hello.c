#include <stdio.h>

int main() {
    int fun;
    scanf("%d", &fun);
    printf("Hello, %d!", fun);
}
