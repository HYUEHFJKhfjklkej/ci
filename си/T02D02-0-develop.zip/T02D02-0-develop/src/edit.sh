#!/bin/bash
file=$1
string1=$2
string2=$3
#echo "первая переменая"
#read string1
if [ -z $string1 ]; then
    echo "пустая строка"
    exit
fi
#echo "вторая переменая"
#read string2
if [ -z $string2 ]; then
    echo "пустая строка"
    exit
fi
#echo "путь"
#read file
if [ -e $file ]; then # e существует файл
    sed -i "" "s/$string1/$string2/g" $file # -i s - это функци замены g все файлы
    Fili_size="$(stat -f %z $file)"
    Date_time="$(date -r $file +"%F %H:%M")"
    sha_sum="$(shasum -a 256 $file | cut -f 1 -d " ")"
    ddd=$(pwd)
echo "$(basename $ddd)/$(basename $file) - $Fili_size - $Date_time - $sha_sum sha256" >> files.log
else
    echo "нет файла"
    exit
fi
