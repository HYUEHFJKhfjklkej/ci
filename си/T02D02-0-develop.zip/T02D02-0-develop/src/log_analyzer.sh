#!/bin/bash
file=$1
if [ -e $file ]; then
#cat $file | wc -l

if [ $file == *.log ]; then
fist_line=$(sort $file | uniq -u | wc -l)
#echo sed -n /src/* /$file
#echo awk '{}' $file sort | uniq -c
#echo awk -n '/RE/{p;q;}' $file
#awk '{print $1}' file.log выводит строки
second_line=$(awk '{print $1}' files.log | uniq | wc -l)
therd_line=$(awk '{print $8}' files.log | uniq | wc -l)
echo $fist_line $second_line $therd_line
else
echo "no file"
fi
else
echo "not *.log exstend"
fi
