int sort(int *a, int n) {
    for (int i = 0; i < n-1; i++) {
        for (int count = 0; count < n-1; count++) {
            if (a[count] > a[count+1]) {
                int temp = a[count];
                a[count] = a[count+1];
                a[count+1] = temp;
            }
        }
    }
    return *a;
}
