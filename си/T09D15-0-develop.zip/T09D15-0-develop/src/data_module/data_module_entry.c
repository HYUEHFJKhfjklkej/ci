#include <stdio.h>
#include "data_process.h"
#include "../data_libs/data_io.h"

int main() {
    double *data;
    int n;
    //  Don`t forget to allocate memory !

    data = input(&n);
    if (data != NULL) {
    if (normalization(data, n))
        output(data, n);
    else
        printf("ERROR");
    } else {
        printf("ERROR");
    }
    free(data);
}
