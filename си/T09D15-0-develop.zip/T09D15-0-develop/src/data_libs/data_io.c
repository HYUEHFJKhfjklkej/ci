#include "data_io.h"

double* input(int *length) {
    scanf("%d", length);
    double *a = (double*)malloc(*length * sizeof(double));
    for (int p = 0; p < *length; p++) {
        scanf("%lf", &a[p]);
    }

    return a;
}

void output(double *data, int n) {
    for (double *p = data; p - data < n; p++) {
        printf("%.2f ", *p);
    }
    printf("\n");
}
