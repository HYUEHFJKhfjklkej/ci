#ifndef SRC_DATA_LIBS_DATA_STAT_H_
#define SRC_DATA_LIBS_DATA_STAT_H_


double max(double *a, int n);
double min(double *a, int n);
double mean(double *a, int n);
double variance(double *a, int n);

#endif  // SRC_DATA_LIBS_DATA_STAT_H_
