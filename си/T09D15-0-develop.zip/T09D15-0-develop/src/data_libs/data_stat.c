#include "data_stat.h"

double max(double *a, int n) {
    double max = *a;
    for (double *p = a; p - a < n; p++) {
        if (max < *p) {
            max = *p;
        }
    }
    return max;
}

double min(double *a, int n) {
    double min = *a;
    for (double *p = a; p - a < n; p++) {
        if (min > *p) {
            min = *p;
        }
    }
    return min;
}

double mean(double *a, int n) {
    double sum = 0;
    for (double *p = a; p - a < n; p++) {
        sum += *p;
    }
    return sum / n;
}

double variance(double *a, int n) {
    double sum = 0;
    for (double *p = a; p - a < n; p++) {
        sum += *p;
    }
    double mean = sum / n;
    double var = 0;
    for (double *p = a; p - a < n; p++) {
        var += ((*p-mean) * (*p - mean));
    }
    return var / n;
}
