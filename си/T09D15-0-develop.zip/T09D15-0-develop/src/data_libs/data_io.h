#ifndef SRC_DATA_LIBS_DATA_IO_H_
#define SRC_DATA_LIBS_DATA_IO_H_

#include <stdio.h>
#include <stdlib.h>
#include <malloc/malloc.h>

double* input(int *length);
void output(double *data, int n);

#endif  // SRC_DATA_LIBS_DATA_IO_H_
