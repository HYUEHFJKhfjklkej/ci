#include "decision.h"
#include <stdio.h>
#include "../data_libs/data_io.h"
int main() {
    double *data;
    int n;
    data = input(&n);
    if (data != NULL) {
        if (make_decision(data, n) == 1) {
            printf("YES");
        } else {
            printf("NO");
        }
    return 0;
    } else {
        printf("n/a");
    }
}
