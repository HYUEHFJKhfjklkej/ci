#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
void read_file(char* file_name);
void write_to_file(char* file_name);
void cezar(int *shift, char* fullpath);
void clean(char* fullpath);
int main() {
    int mode = 0;
    char file_name[1000];
    int shift = 0;
    char dir_path[1000];
    while (mode != -1) {
        fflush(stdin);
        char str;
        if (((scanf("%d%c", &mode, &str) == 2) && (str == '\n')) || ((mode > 0 && mode < 5))) {
            if (mode == 1) {
            read_file(file_name);
        }
        if (mode == 2) {
            write_to_file(file_name);
        }
        if (mode == 3) {
             char *temp_dir;
    char fullpath[1000];
    char err;
    scanf("%d%c", &shift, &err);
    scanf("%s%c", dir_path, &err);
    DIR *dam;
    struct dirent *dir;
    dam = opendir(dir_path);
    if (dam) {
        while ((dir = readdir(dam)) != NULL) {
            temp_dir = dir->d_name;
            strcpy(fullpath, dir_path);
            strcat(fullpath, "/");
            strcat(fullpath, temp_dir);
            int sl = strlen(fullpath);
            if (fullpath[sl - 1] == 'c' && fullpath[sl - 2] == '.') {
                cezar(&shift, fullpath);
            }
            if (fullpath[sl - 1] == 'h' && fullpath[sl - 2] == '.') {
                clean(fullpath);
            }
        }
        closedir(dam);
    }
        }
        } else {
            printf("n/a\n");
        }
    }
}

void read_file(char* file_name) {
    FILE *mf;
    char ch;
    scanf("%s", file_name);
    mf = fopen(file_name, "r");
    if (mf == NULL) {
        printf("n/a\n");
    } else {
        ch = fgetc(mf);
        if (ch != EOF) {
            while (ch != EOF) {
                putchar(ch);
                ch = fgetc(mf);
            }
        } else {
            printf("n/a\n");
        }
        fclose(mf);
    }
}

void write_to_file(char* file_name) {
    FILE *mf = NULL;
    char line[1000];
    fgets(line, 1000, stdin);
    if ((mf = fopen(file_name, "r+")) == NULL) {
        printf("n/a\n");
        fclose(mf);
        } else {
        fseek(mf, 0L, SEEK_END);
        fputs(line, mf);
        fclose(mf);
    }
}

void cezar(int *shift, char* fullpath) {
    FILE * fc;
    fc = fopen(fullpath, "r+");
    char chr;
    chr = fgetc(fc);
    long i = 0;
    while (chr != EOF) {
        fseek(fc, i * sizeof(char), 0);
        fputc((chr + *shift % 256), fc);
        chr = fgetc(fc);
        i++;
    }
    fclose(fc);
}

void clean(char* fullpath) {
    FILE * fool;
    fool = fopen(fullpath, "w");
    fclose(fool);
}
