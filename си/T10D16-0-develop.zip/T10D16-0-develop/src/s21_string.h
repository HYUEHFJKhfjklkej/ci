#ifndef SRC_S21_STRING_H_
#define SRC_S21_STRING_H_
#include <stdio.h>
size_t s21_strlen(char *a);
int s21_strcmp(char *str1, char *str2);
char *s21_strcpy(char *string1, char *string2);
char *s21_strcat(char *str1, char *str2);
char *s21_strchr(const char *a, int i);
#endif  //  SRC_S21_STRING_H_
