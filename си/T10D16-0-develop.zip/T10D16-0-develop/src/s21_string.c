#include <stdio.h>
size_t s21_strlen(char *a) {
    int n = 0;
    while (a[n] != '\0') {
        n++;
    }
    return n;
}
int s21_strcmp(char *str1, char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return (*str1 - *str2);
}
char *s21_strcpy(char *string1, const char *string2) {
    int i;
    i = 0;
    while (string2[i] != '\0') {
        string1[i] = string2[i];
        i++;
    }
    string1[i] = '\0';
    return(string1);
}
char *s21_strcat(char *str1, const char *str2) {
    char *copy;
    copy = str1;
    while (*str1) str1++;
    while (*str2) *str1++ = *str2++;
    *str1 ='\0';
    return(copy);
}
char *s21_strchr(const char *a, int i) {
    while (*a) {
        if (*a == i) {
            return ((char *)a);
        }
        a++;
    }
    return ((void *)0);
}
