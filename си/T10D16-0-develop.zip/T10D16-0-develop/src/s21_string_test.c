#include "s21_string.h"
#include <stdio.h>
size_t s21_strlen(char *a);
int s21_strcmp(char *str1, char *str2);
char *s21_strcpy(char *string1, char *string2);
char *s21_strcat(char *str1, char *str2);
char *s21_strchr(const char *a, int i);
void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void print(char *a);
int main() {
    #ifdef S21_STRLEN
    s21_strlen_test();
    #endif
    #ifdef S21_STRCMP
    s21_strcmp_test();
    #endif
    #ifdef S21_STRCPY
    s21_strcpy_test();
    #endif
    #ifdef S21_STRCAT
    s21_strcat_test();
    #endif
    #ifdef S21_STRCHR
    s21_strchr_test();
    #endif
    return 0;
}
void s21_strchr_test() {
    char *ach, *ach2, *ach3, *ach4;
    char cpyname[100] = "011111111111111111111122222222223333333444";
    int a, b, c, d;
    a = 0;
    b = 1;
    c = 2;
    d = 3;
    ach = s21_strchr(cpyname, a);
    ach2 = s21_strchr(cpyname, b);
    ach3 = s21_strchr(cpyname, c);
    ach4 = s21_strchr(cpyname, d);
    if (ach == NULL) {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("FAIL\n");
    } else {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("%ld", ach-cpyname+1);
        printf("SUCCESS\n");
    }
    if (ach2 == NULL) {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("FAIL\n");
    } else {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("%ld", ach2-cpyname+1);
        printf("SUCCESS\n");
    }
    if (ach3 == NULL) {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("FAIL\n");
    } else {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("%ld", ach3-cpyname+1);
        printf("SUCCESS\n");
    }
    if (ach4 == NULL) {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("FAIL\n");
    } else {
        printf("input:");
        print(cpyname);
        printf("output:");
        printf("%ld", ach4-cpyname+1);
        printf("SUCCESS\n");
    }
}
void s21_strcat_test() {
    char *q, *w, *e, *r;
    char cpyname[100] = "111111111111111111111";
    char cpyname1[100] = "\t\nsd";
    char cpyname2[100] = "  ";
    char cpyname3[100] = "wqewq123";
    char cpycopy[100] = "222";
    char cpycopy1[100] = " 00";
    char cpycopy2[100] = " 123";
    char cpycopy3[100] = " \n";
    q = s21_strcat(cpycopy, cpyname);
    w = s21_strcat(cpycopy1, cpyname1);
    e = s21_strcat(cpycopy2, cpyname2);
    r = s21_strcat(cpycopy3, cpyname3);
    printf("input:");
    print(cpyname);
    printf("output:");
    print(q);
    char q1[100] = "222111111111111111111111";
    if (*q == *q1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname1);
    printf("output:");
    print(w);
    char w2[100] = " 00\t\nsd";
    if (*w == *w2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname2);
    printf("output:");
    print(e);
    char e1[100] = " 123  ";
    if (*e == *e1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname3);
    printf("output:");
    print(r);
    char r1[100] = " \nwqewq123";
    if (*r == *r1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}
void s21_strcpy_test() {
    char *q, *w, *e, *r;
    char cpyname[100] = "111111111111111111111";
    char cpyname1[100] = "\t\nsd";
    char cpyname2[100] = "  ";
    char cpyname3[100] = "wqewq123";
    char cpycopy[100] = " ";
    char cpycopy1[100] = " ";
    char cpycopy2[100] = " ";
    char cpycopy3[100] = " ";
    q = s21_strcpy(cpycopy, cpyname);
    w = s21_strcpy(cpycopy1, cpyname1);
    e = s21_strcpy(cpycopy2, cpyname2);
    r = s21_strcpy(cpycopy3, cpyname3);
    printf("input:");
    print(cpyname);
    printf("output:");
    print(q);
    if (*q == *cpycopy) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname1);
    printf("output:");
    print(w);
    if (*w == *cpycopy1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname2);
    printf("output:");
    print(e);
    if (*e == *cpycopy2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("input:");
    print(cpyname3);
    printf("output:");
    print(r);
    if (*r == *cpycopy3) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}
void s21_strcmp_test() {
    int c, s, d, f = 0;
    char str1[100]
    = "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111";
    char str2[100] = "11111111111111111111111111111111111111111111111111111111111111111111111111111111111";
    char str3[100] = "222";
    char str4[100] = "2222";
    char str5[100] = " ";
    char str6[100] = " ";
    char str7[100] = "   ";
    char str8[100] = "  ";
    c = s21_strcmp(str1, str2);
    s = s21_strcmp(str3, str4);
    d = s21_strcmp(str5, str6);
    f = s21_strcmp(str7, str8);
    if (c == 49) {
        printf("input_1:%s\n", str1);
        printf("input_2:%s\n", str2);
        printf("output:%d\n", c);
        printf("SUCCESS\n");
    } else {
        printf("input_1:%s\n", str1);
        printf("input_2:%s\n", str2);
        printf("output:%d\n", c);
        printf("FAIL\n");
    }
    if (s == -50) {
        printf("input_1:%s\n", str3);
        printf("input_2:%s\n", str4);
        printf("output:%d\n", s);
        printf("SUCCESS\n");
    } else {
        printf("input_1:%s\n", str3);
        printf("input_2:%s\n", str4);
        printf("output:%d\n", s);
        printf("FAIL\n");
    }
    if (d == 0) {
        printf("input_1:%s\n", str5);
        printf("input_2:%s\n", str6);
        printf("output:%d\n", d);
        printf("SUCCESS\n");
    } else {
        printf("input_1:%s\n", str5);
        printf("input_2:%s\n", str6);
        printf("output:%d\n", d);
        printf("FAIL\n");
    }
    if (f == 32) {
        printf("input_1:%s\n", str7);
        printf("input_2:%s\n", str8);
        printf("output:%d\n", f);
        printf("SUCCESS\n");
    } else {
        printf("input_1:%s\n", str7);
        printf("input_2:%s\n", str8);
        printf("output:%d\n", f);
        printf("FAIL\n");
    }
}
void s21_strlen_test() {
    int p, i, j, k, z = 0;
    char stringName[8] = { 'S' , 'a' , 'n' , 'j' , 'a' , 'y' , '3' };
    char stringName1[8] = "  ";
    char stringName2[8] = { '\\' , '\0' , '\n' , 'j' , 'a' , 'y' , '3' };
    char stringName3[8] = "\t";
    char stringName4[8] = "\n";
    p = s21_strlen(stringName);
    i = s21_strlen(stringName1);
    j = s21_strlen(stringName2);
    k = s21_strlen(stringName3);
    z = s21_strlen(stringName4);

    if (p == 7) {
        printf("input:%s\n", stringName);
        printf("output:%d\n", p);
        printf("SUCCESS\n");
    } else {
        printf("input:%s\n", stringName);
        printf("output:%d\n", p);
        printf("FAIL\n");
    }
    if (i == 2) {
        printf("input:%s\n", stringName1);
        printf("output:%d\n", p);
        printf("SUCCESS\n");
    } else {
        printf("input:%s\n", stringName1);
        printf("output:%d\n", i);
        printf("FAIL\n");
    }
    if (j == 1) {
        printf("input:%s\n", stringName2);
        printf("output:%d\n", j);
        printf("SUCCESS\n");
    } else {
        printf("input:%s\n", stringName2);
        printf("output:%d\n", j);
        printf("FAIL\n");
    }
    if (k == 1) {
        printf("input:%s\n", stringName3);
        printf("output:%d\n", k);
        printf("SUCCESS\n");
    } else {
        printf("input:%s\n", stringName3);
        printf("output:%d\n", k);
        printf("FAIL\n");
    }
    if (z == 1) {
        printf("input:%s\n", stringName4);
        printf("output:%d\n", z);
        printf("SUCCESS\n");
    } else {
        printf("input:%s\n", stringName4);
        printf("output:%d\n", z);
        printf("FAIL\n");
    }
}
void print(char *a) {
    int i = 0;
    while (a[i] != '\0') {
        printf("%c", a[i]);
        i++;
        }
    printf("\n");
}
