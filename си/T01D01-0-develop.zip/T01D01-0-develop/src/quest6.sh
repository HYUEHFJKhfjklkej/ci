cd ai_help/key
rm file*
