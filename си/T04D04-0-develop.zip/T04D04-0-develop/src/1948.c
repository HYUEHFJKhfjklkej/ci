// Copyright 2022 )
#include <stdio.h>
#include <math.h>

int function_minus(int x, int y);
int dublicate(int x, int y);
int maximus(int x);

int maximus(int x) {
    int cur_max = 0, abs_x = x, i;
    if (x < 0) {
        abs_x = x * (-1);
    }
    i = 2;
    while (i <= abs_x) {
        if (function_minus(abs_x, i) == 1) {
            abs_x = dublicate(abs_x, i);
            cur_max = i;
        } else {
            i += 1;
        }
    }
    return cur_max;
}

int function_minus(int x, int y) {
    int chop;
    chop = x;
    while (chop > 0) {
        chop -= y;
    }
    if (chop == 0)
        return 1;
    else
        return 0;
}

int dublicate(int x, int y) {
    int chop, i;
    chop = x;
    i = 0;
    while (chop > 0) {
        chop -= y;
        i += 1;
    }
    return i;
}

int main() {
    int a;
    char ch;
    scanf("%i", & a);
    scanf("%c", & ch);
    if (ch != '\n') {
        printf("n/a");
    } else {
        if (a <= 1 && a >= -1) {
            printf("n/a");
        } else {
            int ans = maximus(a); {
                printf("%d", ans);
            }
        }
    }
    return 0;
}