#include <stdio.h>

int sum_hex(char sym);
int hex_sum(char a, char b);
int poket_1();
int poket_2();

int poket_2() {
    char s1, s2 = ' ', line[1000];
    int i = 0;
    do {
        scanf("%c", & s1);
        if (s1 == '\n') {
            break;
        }
        if (s2 != ' ') {
            printf("n/a");
            return 0;
        }
        line[i] = s1;
        i++;
        scanf("%c", & s2);
    } while (s1 != '\n' && s2 != '\n');
    for (int j = 0; j < i; j++) {
        sum_hex(line[j]);
    }
    return 0;
}

int poket_1() {
    char s1, s2, s3 = ' ', line[1000];
    int i = 0;
    do {
        scanf("%c", & s1);
        if (s1 == '\n')
            break;
        scanf("%c", & s2);
        if (s3 != ' ' || s2 == ' ') {
            printf("n/a");
            return 0;
        }
        line[i] = s1;
        i++;
        line[i] = s2;
        i++;
        scanf("%c", & s3);
    } while (s1 != '\n' && s3 != '\n');
    for (int j = 0; j < i; j += 2) {
        char f = line[j], s = line[j + 1];
        hex_sum(f, s);
    }
    return 0;
}

int hex_sum(char a, char b) {
    int decimal = 0;

    if (b >= '0' && b <= '9') {
        decimal += (b - 48);
    } else if (b >= 'A' && b <= 'F') {
        decimal += (b - 55);
    } else if (b >= 'a' && b <= 'f') {
        decimal += (b - 87);
    }

    if (a >= '0' && a <= '9') {
        decimal += (a - 48) * 16;
    } else if (a >= 'A' && a <= 'F') {
        decimal += (a - 55) * 16;
    } else if (a >= 'a' && a <= 'f') {
        decimal += (a - 87) * 16;
    }
    char ans = decimal;
    printf("%c ", ans);
    return 0;
}

int
sum_hex(char sym) {
    int a = sym - 0, res, rem;
    char ans[2];
    res = a / 16;
    rem = a % 16;
    if (res <= 9)
        ans[0] = '0' + res;
    else
        ans[0] = 'A' + res - 10;

    if (rem <= 9)
        ans[1] = '0' + rem;
    else
        ans[1] = 'A' + rem - 10;
    printf("%c%c ", ans[0], ans[1]);
    return 0;
}

int main(int argc, char * argv[]) {
    if (argc != 2) {
        printf("n/a");
        return 0;
    }
    if ( * argv[1] == '1' ) {
        poket_1();
        return 0;
    }
    if ( * argv[1] == '0' ) {
        poket_2();
        return 0;
    }
    printf("n/a");
    return 0;
}