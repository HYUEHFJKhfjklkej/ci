#include <stdio.h>
#include <math.h>

int fibonach(int n) {
    if (n == 1)
        return 1;
    if (n == 0)
        return 0;
    int f1 = fibonach(n - 1);
    int f2 = fibonach(n - 2);
    int f = f1 + f2;
    return f;
}

int main() {
    int a;
    char ch;
    scanf("%i", & a);
    scanf("%c", & ch);
    if (ch != '\n') {
        printf("n/a");
    } else {
        if (a < 0) {
            printf("n/a");
        } else {
            int ans;
            ans = fibonach(a);
            printf("%d", ans);
        }
    }
    return 0;
}