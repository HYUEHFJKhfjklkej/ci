/*------------------------------------
	Здравствуй, человек!
	Чтобы получить ключ 
	поработай с комментариями.
-------------------------------------*/

#include <stdio.h>
#define NMAX 10

int input(float *n);
int input_2(int *a, int n);
void output(int *buffer, int length);
int sum_numberbers(int *buffer, int length);
int find_numberbers(int* buffer, int length, int numberber, int* numberbers);

/*------------------------------------
	Функция получает массив данных 
	через stdin.
	Выдает в stdout особую сумму
	и сформированный массив 
	специальных элементов
	(выбранных с помощью найденной суммы):
	это и будет частью ключа
-------------------------------------*/
int main() {
    float n;
    int number;
    char cr;
    int data[NMAX] = {};
    int data_2[NMAX] = {};
    if ((input(&n) == 1)) {
        printf("n/a");
        return 1;
    }
    if ((input_2(data, n) == 1)) {
        printf("n/a");
        return 1;
    }
    cr = getchar();
    if ((cr != '\n')) {
        printf("n/a");
        return 1;
    }
    number = sum_numberbers(data, n);
    find_numberbers(data, n, number, data_2);
    printf("%d\n", number);
    output(data_2, find_numberbers(data, n, number, data_2));
    return 0;
}

int input(float *n) {
    int ceaker = 0;
    if (((scanf("%f", n) == 1)) && ((int)*n > 0) && ((int)*n <= NMAX)) {
        if ((int)*n != *n) {
        ceaker = 1;
        }
    } else {
        ceaker = 1;
    }
    return ceaker;
}

int input_2(int *a, int n) {
    int ceaker = 0;
    for (int *p = a; p - a < n; p++) {
    if (scanf("%d", p) != 1) {
        ceaker = 1;
    }
    }
    return ceaker;
}

/*------------------------------------
	Функция должна находить
	сумму четных элементов 
	с 0-й позиции.
-------------------------------------*/
int sum_numberbers(int *buffer, int length) {
    int sum = 0;
    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum = sum + buffer[i];
        }
    }
    return sum;
}

/*------------------------------------
	Функция должна находить
	все элементы, на которые нацело
	делится переданное число и
	записывает их в выходной массив.
-------------------------------------*/
int find_numberbers(int* buffer, int length, int numberber, int* numberbers) {
    int j = 0;
    for (int i = 0; i < length; i++) {
        if ((buffer[i] != 0) && (numberber % buffer[i] == 0)) {
            numberbers[j] = buffer[i];
            j++;
        }
        }
    return j;
}

void output(int *a, int n) {
    for (int i = 0 ; i < n; i ++) {
       if ((n-1) == i) {
        printf("%d", a[i]);
        } else {
           printf("%d ", a[i]);
       }
}
}
