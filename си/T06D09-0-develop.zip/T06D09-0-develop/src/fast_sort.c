#include <stdio.h>
#define NMAX 10
void counting_sort(int *input, int k, int n);
void print_arr(int *input, int left, int right);
void swap(int *a, int *b);
int partition(int *input, int left, int right);
void quick_sort(int *input, int left, int right);

void counting_sort(int *input, int k, int n) {
    int inc, output[99], count[100];
    for (inc = 0; inc <= k; inc++)
        count[inc] = 0;
    for (inc = 1; inc <= n; inc++)
        count[input[inc]] = count[input[inc]] + 1;
    for (inc = 1; inc <= k; inc++)
        count[inc] = count[inc] + count[inc - 1];
    for (inc = n; inc >= 1; inc--) {
        output[count[input[inc]]] = input[inc];
        count[input[inc]] = count[input[inc]] - 1;
    }
    for (inc = 1; inc <= n; inc++) {
        if ((n) == inc) {
        printf("%d", output[inc]);
        } else {
        printf("%d ", output[inc]);
        }
    }
}

int main() {
    int n, k = 0, inc, input[99];
    n = NMAX;
    char cr;
    int arr[NMAX] = {0};
    for (inc = 1; inc <= n; inc++) {
        if ((scanf("%d", &input[inc])) == 1) {
            if (input[inc] > k) {
            k = input[inc];
        }
        } else {
            printf("n/a");
            return 0;
        }
    }
    cr = getchar();
    if ((cr != '\n')) {
        printf("n/a");
        return 0;
    }
    for (int i = 0 ; i < 10; i ++) {
        arr[i] = input[i+1];
    }
    counting_sort(input, k, n);
    printf("\n");
    quick_sort(arr, 0, NMAX - 1);
    print_arr(arr, 0, NMAX - 1);
    return 0;
}

void print_arr(int *input, int left, int right) {
    printf("%d", input[left]);
    int i;
    for (i = left + 1 ; i <= right; i++) {
        printf(",%d", input[i]);
        }
}
void swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

int partition(int *input, int left, int right) {
  int pivot = input[right];
    int i = (left-1);

    for (int j = left; j <= right- 1; j++) {
        if (input[j] < pivot) {
            i++;
            swap(&input[i], &input[j]);
        }
    }
    swap(&input[i + 1], &input[right]);
    return (i + 1);
}
void quick_sort(int *input, int left, int right) {
    if (left < right) {
        int partition_index = partition(input, left, right);
        quick_sort(input, left, partition_index-1);
        quick_sort(input, partition_index+1, right);
  }
}

