#include <stdio.h>
#define NMAX 10

int input(int *a);
void sort(int *a);
void output(int *a);
int main() {
    int data[NMAX];
    if ((input(data) != 1)) {
    sort(data);
    output(data);
    } else {
        printf("n/a");
    }
}

int input(int*a) {
    int flag = 0;
    char cr;
    for (int *p = a; p - a < NMAX; p++) {
        if (scanf("%d", p) != 1) {
            flag = 1;
        }
    }
    cr = getchar();
    if ((cr != '\n')) {
        flag = 1;
    }
    return flag;
}
void sort(int *a) {
    for (int i = 0; i < NMAX-1; i++) {
        for (int count = 0; count < NMAX-1; count++) {
            if (a[count] > a[count+1]) {
                int temp = a[count];
                a[count] = a[count+1];
                a[count+1] = temp;
            }
        }
    }
}
void output(int *a) {
for (int i = 0 ; i < NMAX; i ++) {
       if ((NMAX-1) == i) {
        printf("%d", a[i]);
        } else {
           printf("%d ", a[i]);
       }
}
}
