
void _nmi_handler() {
	for(;;);
}

void _on_bootstrap() {
	
}

void _on_reset() {
	
}
