#include <stdint.h>
int buttonOne();
int buttonTwo();
int buttonThree();
int buttonFour();

int switchOne();
int switchTwo();
int switchThree();
int switchFour();
